<!doctype html>
<html lang="en">
@include("book.head")
<body>
<header>

</header>
<div class="col-xs-6 col-xs-offset-3">
    @yield("main_content")
</div>
<footer>

</footer>
@yield("popup")
</body>
</html>